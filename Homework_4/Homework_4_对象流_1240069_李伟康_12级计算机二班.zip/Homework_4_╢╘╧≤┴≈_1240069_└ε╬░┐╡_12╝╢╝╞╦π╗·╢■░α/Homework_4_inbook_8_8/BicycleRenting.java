package Homework_4_inbook_8_8;

public interface BicycleRenting {
	void GetBicycles(Bicycle bb);
}
