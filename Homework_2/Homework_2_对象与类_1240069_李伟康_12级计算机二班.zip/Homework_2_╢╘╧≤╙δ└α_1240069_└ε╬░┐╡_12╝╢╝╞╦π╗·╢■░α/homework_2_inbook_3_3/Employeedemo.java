package homework_2_inbook_3_3;

public class Employeedemo {
	
	public static void main(String[] args) {
		Employee [] employee = new Employee[23];
		for(int count = 0; count < employee.length ; count ++){
			employee[count] = new Employee();
		}
		//test											//to be continued...
		System.out.println("Welcome to test!");
		//test insert
		employee[0].user_insert();
		
		//test update
		employee[0].user_update();
		
		//test insert
		employee[0].user_delete();
		employee[0].user_show();
	}
}
