package homework_2_inbook_3_4;

public class Passengerdemo {
	
	public static void main(String[] args) {
		Passenger [] passenger = new Passenger[23];
		for(int count = 0; count < passenger.length ; count ++){
			passenger[count] = new Passenger();
		}
		//test											//to be continued...
		System.out.println("Welcome to test!");
		//test insert
		passenger[0].user_insert();
		
		//test update
		passenger[0].user_update();
		
		//test insert
		passenger[0].user_delete();
	}
}
