package Homework_3_inbook_6_8;

public interface BicycleRenting {
	void GetBicycles(Bicycle bb);
}
