package Homework_3_inbook_7_8;

public interface BicycleRenting {
	void GetBicycles(Bicycle bb);
}
