package Bank;

public class Account {
//data
	//账户信息
	int id;
	float money;
	int t_number;
	
//method
	public Account(int id, float money,int t_number){
		this.id = id;
		this.money = money;
		this.t_number = t_number;
	}	
}
